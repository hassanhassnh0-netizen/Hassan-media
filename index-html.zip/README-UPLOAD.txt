HASSAN MEDIA WEBSITE
=====================

Upload ALL files in this folder to the ROOT of your GitHub repository.

Files:
- index.html
- style.css
- services.html
- social-media.html
- content.html
- seo.html
- ads.html
- video.html
- growth.html
- about.html
- contact.html

IMPORTANT:
Do not put these files inside another folder in the GitHub repository.
index.html and style.css must be at the same level.

GitHub Pages:
Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save

Then open:
https://hassanhassnh0-netizen.github.io/Hassan-media/
